__author__ = "Inada Naoki <songofacandy@gmail.com>"
__version__ = "2.2.7"
version_info = (2, 2, 7, "final", 0)
